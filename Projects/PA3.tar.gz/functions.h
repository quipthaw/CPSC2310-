#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


/**************************
 *Manning Graham                              
 *CPSC 2310 fall 2020 	    
 *UserName: Mcgraha
 *Instructor:  Dr. Yvon Feaster  
 *************************/


//Helper Function that goes through and displays the 
//multiplication process. 
void multiply(int , int );


//Helper Function that displays the binary numbers 
//throughout calculation 
void print_data( int [], int []);


//Helper Function that displays the final Binary Number. 
//Also calculates and displays its final decimal value.
void final_answer( int [], int []);


//Helper Function used to convert a decimal value into Binary. 
void dec_to_bin(int ptr[], int num);


//Helper Function used to convert a Binary number into Decimal.
int bin_to_dec(int []);


//Helper Function used to shift Bytes in both binary Numbers. 
void shift(int accum[], int q_arr[]);


//Helper Function used to add two Binary numbers together.
void add(int [], int[] ,int );


//Helper function used to gain and verify that the initial User Input 
//is legal, promping them to enter a legal value if otherwise. 
void get_nums();

