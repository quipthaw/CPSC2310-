
#include "functions.h"

/**************************
 *Manning Graham                              
 *CPSC 2310 fall 2020 	    
 *UserName: Mcgraha
 *Instructor:  Dr. Yvon Feaster  
 *************************/

int main()
{
    get_nums();
    return 0;    
}