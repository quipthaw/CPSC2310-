
#include "functions.h"


/**************************
 *Manning Graham                              
 *CPSC 2310 fall 2020 	    
 *UserName: Mcgraha
 *Instructor:  Dr. Yvon Feaster  
 *************************/


void get_nums()
{
    int m,q;
    printf("\nEnter the Multiplicand (M) value: ");
    scanf("%d", &m);
    while(!((m <= 255) && (m >= 0)))
    {
        printf("\nError, M Value Must Be Within Range, 0 - 255.\nPlease Try Again.\n");
        printf("\nEnter the Multiplicand (M) value: ");
        scanf("%d", &m);
    }

    printf("\nEnter the Multiplier (Q) value: ");
    scanf("%d", &q);
    while(!((q <= 255) && (q >= 0)))
    {
        printf("\nError, Q Value Must Be Within Range, 0 - 255.\nPlease Try Again.\n");
        printf("\nEnter the Multiplier (Q) value: ");
        scanf("%d", &q);
    }
    multiply(m, q);
}



void print_data( int a[], int q[])
{
    int c = 0;
    if(a[8] == 1) c = 1;
    printf ("        %d     ", c);

    for(int i = 7;i>=0;i--) printf("%d",a[i]);
    printf("    ");
    
    for(int i = 7;i >= 0;i--) printf("%d",q[i]);    
    printf("\n"); 
}



void final_answer( int a[], int q[])
{
    int total_sum = 0;
    printf("Final Answer in Binary = ");
    
    for(int i = 7; i >=0; i--)
    {   
        printf("%d", a[i]);
        if(a[i] == 1)total_sum += pow(2,i+8);
    }
    printf(" ");
    
    for(int i = 7; i >=0; i--)
    {
        printf("%d", q[i]);
        if(q[i] == 1)total_sum += pow(2,i);
    }
    printf(", in Decimal = %d\n\n",total_sum);
}



void dec_to_bin( int arr[], int num)
{
    for(int i=0; num>0; i++)    
    {    
        arr[i] = num%2;    
        num = num/2;  
    }
}



int bin_to_dec(int arr[])
{
    int sum = 0; 
    for(int i = 0; i<8; i++)
    {
        if(arr[i] == 1) sum += pow(2,i);
    }
    return sum;
}



void add(int accum[], int m_arr[], int lsb)
{
    if(lsb == 1)
    {
        printf("           +  ");
        
        for(int i = 7; i >= 0; i--) printf("%d", m_arr[i]);

        printf("            LSB = 1, Adding M to ACC\n");   
        
        int a_sum = bin_to_dec(accum);
        int m_sum = bin_to_dec(m_arr);
        a_sum += m_sum;
        dec_to_bin(accum, a_sum);
    }
    else printf("           +  00000000            LSB = 0, No Add to ACC \n");
    printf("        -------------------------------------------------\n");
}



void shift( int accum[], int q_arr[])
{
    for(int i = 0; i < 8; i++)
    {
        if(i!=7) q_arr[i] = q_arr[i+1];
        else q_arr[7] = accum[0]; 
    }
    for(int i = 0; i < 9; i++)accum[i] = accum[i+1];
    printf("                                  Shift >> 1\n");
}



void multiply(int m, int q)
{
    int carry = 0;
    int acc = 0;
    printf("\n M = Multiplicand = %d\n", m);
    printf(" Q = Multiplier = %d\n", q);
    printf(" C = Carry = %d\n", carry);
    printf(" ACC = Accumulator = %d\n\n", acc);
    
    int accum[] = {0,0,0,0,0,0,0,0,0,0};
    int q_arr[] = {0,0,0,0,0,0,0,0,0,0};
    int m_arr[] = {0,0,0,0,0,0,0,0,0,0};

    dec_to_bin(q_arr, q);
    dec_to_bin(m_arr, m);

    printf(" Step 0     initialize the data  M = ");
    for(int i = 7;i>=0;i--){ printf("%d",m_arr[i]); }       
    printf(" (%d)  C = %d  ACC = %d  Q = ", m, carry, acc);
    for(int i = 7;i>=0;i--){ printf("%d",q_arr[i]); }
    printf(" (%d)\n\n        C        ACC         Q     ", q);

    for(int i = 1; i <= 8; i++)
    {
        printf("\n Step %d\n", i);
        print_data( accum, q_arr);
        add(accum, m_arr, q_arr[0]);
        print_data( accum, q_arr);
        shift(accum, q_arr);
        print_data( accum, q_arr);
        printf("\n");
    }
    final_answer(accum, q_arr);
} 

