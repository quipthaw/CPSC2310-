

/**************************
 *Manning Graham                              
 *CPSC 2310 fall 2020 	    
 *UserName: Mcgraha
 *Instructor:  Dr. Yvon Feaster  
 *************************/

 I didnt have many problems with this assignement, I feel it was fairly straight forward.
 I did at first have trouble with deciding how to hold the Binary information( as an int, vector, pointer, or array), 
 And ultimately felt more comfortable using arrays.
 I also had some trouble getting the format of the multiplication table exactly correct, 
 but with enough time I figured it out. 
 Overall I liked this assignment, It wasn't so challenging that I couldn't do it in time, but also challenging enough that I 
 feel I learned a lot more about binary multiplication. 