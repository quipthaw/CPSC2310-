/**************************
 *Your name: Manning Graham
 *CPSC 2310 fall 2020        
 *UserName: Mcgraha                       
 *Instructor:  Dr. Yvon Feaster  
*************************/


#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <stdio.h>

void checkArg(int); 
void checkFile(FILE* );  
int getFileCount(FILE* );
void retFP(FILE* fp); 
void readFile(char* , FILE* , int ); 
void ASCII(char* , FILE* , int ); 
void Binary(char* , FILE* , int); 
void print(void (*fp)(char* , FILE* , int ), char*, FILE*, int);

#endif