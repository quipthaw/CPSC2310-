/**************************
 *Your name: Manning Graham
 *CPSC 2310 fall 2020        
 *UserName: Mcgraha                       
 *Instructor:  Dr. Yvon Feaster  
*************************/


I didn't have many problems with this assignment other than the fread and ftell 
functions and macros that I did not already know, and all I did to fix them was
a quick google search. 

Overall I liked this assignment because it was a good 
challenge. It was a simple task but, its complex parts helped me learn 
much better than I would have otherwise. 
