/**************************
 *Your name: Manning Graham
 *CPSC 2310 fall 2020        
 *UserName: Mcgraha                       
 *Instructor:  Dr. Yvon Feaster  
*************************/


#include "functions.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    //Checks the number of arguments on the command line.
    checkArg(argc); 

    //Creates and opens the input and output file pointers
    FILE *inf, *outf;    
    inf = fopen(argv[1], "r");
    outf = fopen(argv[2], "w");

    //check the success of the opening of the file pointers
    checkFile(inf);
    checkFile(outf);
    
    //Gets the count of characters in the file.
    int count = getFileCount(inf);
    
    //Dynamically allocates the memory for the array of characters 
    //that will hold the characters of the file. 
    char * array = malloc(count * sizeof(array)); 

    //Reads the file, storing each character, including spaces, in the array.
    readFile( array, inf , count);

    //Creates the function pointer that will be used to print the ascii and 
    //binary representations of the file.
    void (*ascii)() = &ASCII;
    void (*binary)() = &Binary;

    //Calls the print function once for the ascii then for the binary. 
    print(ascii, array, outf, count);
    print(binary, array, outf, count);

    //Closes the files
    fclose(inf);
    fclose(outf);

    //Frees the dynamically allocated memory
    free(array);
    return 0;
}


