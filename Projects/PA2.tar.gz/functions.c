/**************************
 *Your name: Manning Graham
 *CPSC 2310 fall 2020        
 *UserName: Mcgraha                       
 *Instructor:  Dr. Yvon Feaster  
*************************/
#include "functions.h"
#include <stdio.h>
#include <stdlib.h>

//Checks the Number of arguments and returns an error if there are not enough
void checkArg(int num)
{
    if( num < 3)
    {
        fprintf(stderr, "Not enough arguments\n");
        exit(1);
    }
}

//checks to see if the file opened properly and returns an error if it does not
void checkFile(FILE* f)
{
    if ( f == NULL) 
    {
        fprintf(stderr, "fopen() failed in file %s at line %d of function %s\n", __FILE__, __LINE__, __FUNCTION__);
        exit(1);
    }
}

//gets the count of the number of characters in the file 
//then returns that number after resetting file pointer 
//to origina position
int getFileCount(FILE* f)
{
    char c;
    int count = 0;
    while( c != EOF)
    {
        c = getc(f);
        count = count + 1; 
    }
    retFP(f);
    return count;
}

//resets file pointer to beginning of the file
void retFP(FILE* fp)
{
    fprintf(stderr, "Original position is %ld\n", ftell(fp));
    
    if(fseek(fp , 0 , SEEK_SET )== 0)
    {
        fprintf(stderr,"New position is %ld\n", ftell(fp));
    }

    else
    {
        fprintf(stderr, "fseek failed\n");
        exit(0);
    }
}

//reads all characters in file then stores them in an array
void readFile(char* c, FILE* f , int i)
{
    int count = fread(c, i, i, f);
    
    if(count > 0)
    {
        fprintf(stderr, "fread failed\n");
        exit(0);
    }
    
    else
    {
        retFP(f);
    }
}

//prints to output file the ascii value of each character
void ASCII(char* c, FILE* f, int i)
{
    
    fprintf(f,"\nASCII:");
    int line = 1, temp = 0;
    fprintf(f,"\n%d.", line);
    
    while(temp < i - 1 )
    {    
        int num = c[temp];
        fprintf(f," %d", num);
        temp++;
        if(temp%9 == 0)
        {
            line++;
            fprintf(f,"\n%d.", line);
        }
    }  
    fprintf(f,"\n\n");
}

//prints to outfile the binary value of each character. 
void Binary(char* c, FILE* f, int i)
{
    fprintf(f,"Binary:\n");

    int j = 0;
    while(j < i -1)
    {    
        fprintf(f,"%d. ", j + 1);
         for (int k = 7; k >= 0; --k)
        {
            int number = ((c[j] & (1 << k)) ? 1 : 0 );
            fprintf(f,"%d ", number);
        }

        fprintf(f,"\n");
        j++;
    }  
    fprintf(f,"\n");
}

//calls the ascii and binary functions to print.
void print(void (*fp)( char*, FILE*, int ), char* c, FILE* f, int i)
{
   (*fp)( c, f, i);
}
